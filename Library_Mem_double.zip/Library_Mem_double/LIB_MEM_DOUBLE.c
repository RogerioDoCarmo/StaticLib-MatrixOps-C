#include <stdio.h>
#include <stdlib.h>

#include "LIB_MEM_DOUBLE.h"

double ** aloca(int l, int c) {
    int i;
    double **pm;
    pm = (double **) calloc(l, sizeof(double *));

    for (i = 0; i < l; i++) {
        pm[i] = (double *) calloc(c,sizeof(double));
    }
    return (pm);
}

void libera(int l, double **pm) {
    int i;
    for (i = 0; i < l; i++) {
        free(pm[i]);
    }
    free(pm);
}
