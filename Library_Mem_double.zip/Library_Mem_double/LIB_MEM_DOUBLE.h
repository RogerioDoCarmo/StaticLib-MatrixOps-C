#ifndef LIB_MEM_DOUBLE_H_INCLUDED
#define LIB_MEM_DOUBLE_H_INCLUDED

double ** aloca(int, int);
void libera(int, double **);

#endif // LIB_MEM_DOUBLE_H_INCLUDED
